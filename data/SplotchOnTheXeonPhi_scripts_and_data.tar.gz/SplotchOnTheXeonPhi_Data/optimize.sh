## This script assumes you have built various executables with different optimizations applied
## They should be named Splotch6-1 Splotch6-2 ... etc 
## The optimized executables are run both with and without 2MB buffer allocation
#!/bin/bash

echo "Unsetting MIC_USE_2MB_BUFFERS" > opt_1_${i}.log
unset MIC_USE_2MB_BUFFERS

for i in $(seq 1 4)
do

echo "Splotch ID ${i} run:" >> opt_1_${i}.log  
./Splotch6-${i} snap068.par >> opt_1_${i}.log

done

echo "Setting MIC_USE_2MB_BUFFER=64k" > opt_2_${i}.log
export MIC_USE_2MB_BUFFERS=64k

for i in $(seq 1 4)
do

echo "Splotch ID ${i} run:" >> opt_2_${i}.log  
./Splotch6-${i} snap068.par >> opt_2_${i}.log

done
