#!/bin/bash

SPLOTCH_EXE=Splotch6-DMC-offload

for i in 2076000 1076000 976000 800000 600000 400000 376000
do
echo "camera_y=${i}" > scratch
echo "outfile=out${i}" >> scratch
cat scratch input.par > scratch.par

./${SPLOTCH_EXE} scratch.par

done
