#!/bin/bash

SPLOTCH_EXE=Splotch6-DMC-offload

echo "scene_file=orbit.scene" > scratch
cat scratch snap068.par > scratch.par

./${SPLOTCH_EXE} scratch.par

