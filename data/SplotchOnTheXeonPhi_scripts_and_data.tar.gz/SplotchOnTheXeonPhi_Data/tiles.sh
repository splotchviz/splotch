#!/bin/bash
## Example with subset of tested tile sizes

SPLOTCH_EXE=Splotch6-DMC-offload

for j in 16 32 40 64
do
for i in 2076000 1076000 976000 800000 600000 400000 376000
do
echo "tile_size=${j}" > scratch
echo "camera_y=${i}" > scratch
echo "outfile=out_${j}_${i}" >> scratch
cat scratch snap068.par > scratch.par

./${SPLOTCH_EXE} scratch.par
done
done
